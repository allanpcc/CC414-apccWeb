'use strict'

var async = require("async");
var AWS = require("aws-sdk");
var http = require("http");
require("string_format");
var lambda = new AWS.Lambda({"region": "us-east-1"});
var s3 = new AWS.S3({ region: "us-east-1"});
var bucket = "allan-marvel";

var apiKey = "2e0d738914b3a22464a32992a2a57d69";
var ts = "18092017";
var myhash = "43e57955df3ac4f1bfcabdc1c1835f75";
var getComicsTemplateUrl = "http://gateway.marvel.com/v1/public/characters/{0}/comics?apikey={1}&ts={2}&hash={3}&offset={4}&limit=100"

console.log("Log desde ComicSingle");

module.exports.get = (event, context, callback) => {
  var url = getComicsTemplateUrl.format(event.characterId, apiKey, ts, myhash, event.offset);
  var comicTotal = event.max;
  var comicTitles =[];

  var params ={
   Bucket: bucket
  };
  s3.headBucket(params, function(err, data) {
   if (err) {
     console.log(err, err.stack);
   }
   else {
     console.log("Success");
     console.log(data);
   }
  });


  http.get(url, (res) => {
    res.setEncoding('utf8');
    var totalData="";

    res.on("data", (data) => {
      totalData += data;
    });

    res.on("end", (data) => {
      var comics = JSON.parse(totalData);
      //console.log(data);
      comics["data"]["results"].map(
        function(evt){
          comicTitles.push(evt.title);
        }
      );
      if(comicTitles.length == comics["data"]["count"]){
        callback(null, comicTitles);
      };
    });
  });
};
