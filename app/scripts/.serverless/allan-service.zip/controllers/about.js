'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
