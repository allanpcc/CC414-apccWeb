'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw5Ctrl
 * @description
 * # HwviewsHw5Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw5Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
