'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw12Ctrl
 * @description
 * # HwviewsHw12Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw12Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
