'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw2Ctrl
 * @description
 * # HwviewsHw2Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw2Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
