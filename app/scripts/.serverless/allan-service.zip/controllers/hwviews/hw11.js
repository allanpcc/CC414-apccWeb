'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw11Ctrl
 * @description
 * # HwviewsHw11Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw11Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
