'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw9Ctrl
 * @description
 * # HwviewsHw9Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw9Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
