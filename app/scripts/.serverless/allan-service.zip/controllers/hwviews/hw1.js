'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw1Ctrl
 * @description
 * # HwviewsHw1Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw1Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
