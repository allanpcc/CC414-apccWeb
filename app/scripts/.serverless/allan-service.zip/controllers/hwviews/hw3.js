'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw3Ctrl
 * @description
 * # HwviewsHw3Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw3Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
