'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw8Ctrl
 * @description
 * # HwviewsHw8Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw8Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
