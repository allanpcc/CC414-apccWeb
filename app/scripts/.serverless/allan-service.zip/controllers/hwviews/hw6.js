'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw6Ctrl
 * @description
 * # HwviewsHw6Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw6Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
