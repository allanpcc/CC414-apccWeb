'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HwviewsHw10Ctrl
 * @description
 * # HwviewsHw10Ctrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HwviewsHw10Ctrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
