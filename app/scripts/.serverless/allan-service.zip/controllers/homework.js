'use strict';

/**
 * @ngdoc function
 * @name allancastroApp.controller:HomeworkCtrl
 * @description
 * # HomeworkCtrl
 * Controller of the allancastroApp
 */
angular.module('allancastroApp')
  .controller('HomeworkCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
